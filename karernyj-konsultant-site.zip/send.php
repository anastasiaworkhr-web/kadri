<?php
// Принимает заявку с формы и отправляет её на почту. Нужен хостинг с PHP.
header('Content-Type: application/json; charset=utf-8');
$TO = 'anastasia.work.hr@gmail.com'; // почта, на которую приходят заявки
function fail(){ http_response_code(400); echo '{"ok":false}'; exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !empty($_POST['website']) || empty($_POST['consent'])) fail();
function f($k){ return trim(strip_tags($_POST[$k] ?? '')); }
$n = f('name'); $t = f('contact'); $p = f('position');
if ($n === '' || $t === '') fail();
$host = preg_replace('/^www\./', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
$subject = '=?UTF-8?B?' . base64_encode('Заявка с сайта: обсудить подбор') . '?=';
$body = "Имя: $n\nТелефон или мессенджер: $t\nКакую позицию нужно закрыть: $p\nСогласие на обработку данных: да\nДата: " . date('d.m.Y H:i');
$headers = "From: noreply@$host\r\nContent-Type: text/plain; charset=UTF-8\r\n";
echo mail($TO, $subject, $body, $headers) ? '{"ok":true}' : '{"ok":false}';
