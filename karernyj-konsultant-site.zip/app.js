const bg=document.getElementById("bg"),nav=document.getElementById("nav");
bg.onclick=()=>{const o=nav.classList.toggle("open");bg.setAttribute("aria-expanded",o)};
const TO="anastasia.work.hr@gmail.com";
document.querySelectorAll("form#lead").forEach(f=>{f.onsubmit=async e=>{e.preventDefault();
const ok=f.querySelector(".ok"),fd=new FormData(f);let sent=false;
try{const r=await fetch(f.action,{method:"POST",body:fd});const j=await r.json();sent=j.ok===true}catch(_){}
if(sent){ok.textContent="Заявка отправлена. Ответим в течение дня.";f.reset()}
else{const b="Имя: "+fd.get("name")+"\nТелефон или мессенджер: "+fd.get("contact")+"\nКакую позицию нужно закрыть: "+fd.get("position");
ok.textContent="Откроется письмо с вашей заявкой. Нажмите «Отправить» в почтовой программе. Если письмо не открылось, напишите на "+TO+".";
location.href="mailto:"+TO+"?subject="+encodeURIComponent("Заявка с сайта: обсудить подбор")+"&body="+encodeURIComponent(b)}
ok.style.display="block"}});
const lb=document.getElementById("lb"),box=lb.querySelector(".box");let list=[],idx=0;
const show=()=>{box.innerHTML="";box.append(list[idx].cloneNode(true))};
document.querySelectorAll(".shot").forEach(b=>b.onclick=()=>{list=[...b.closest(".grid").querySelectorAll(".shot img")];idx=list.indexOf(b.querySelector("img"));show();lb.classList.add("on");lb.querySelector("button").focus()});
lb.querySelector("button").onclick=()=>lb.classList.remove("on");
lb.onclick=e=>{if(e.target===lb)lb.classList.remove("on")};
addEventListener("keydown",e=>{if(!lb.classList.contains("on"))return;if(e.key==="Escape")lb.classList.remove("on");if(e.key==="ArrowRight"){idx=(idx+1)%list.length;show()}if(e.key==="ArrowLeft"){idx=(idx-1+list.length)%list.length;show()}});
